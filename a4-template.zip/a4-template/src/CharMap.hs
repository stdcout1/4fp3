module CharMap
  ( CharMap,
    empty,
    isEmpty,
    singleton,
    isSingleton,
    insertWith,
    insert,
    lookup,
    foldlWithKey',
    fromList,
    toAscList,
  )
where

import Data.Foldable (foldl')
import Prelude hiding (lookup)

-- | Node colour for balancing invariants.
data Colour
  = R
  | B
  deriving (Eq, Show)

-- | Red-Black Tree specialized for 'Char' keys.
--
-- Guarantees \(O(\log{}(A))\) operations (where \(A\) is the alphabet size) by
-- enforcing two structural invariants:
--
-- 1. No red node has a red child.
-- 2. Every path from the root to an empty node contains the same number of
--    black nodes.
--
-- Follows Okasaki's Red-Black Tree (Ch. 3 of "Purely Functional Data
-- Structures").
data CharMap a
  = Empty
  | Node !Colour !(CharMap a) !Char !a !(CharMap a)
  deriving (Eq, Show)

-- | The empty map. \(O(1)\).
empty :: CharMap a
empty = Empty

-- | Check if a map is empty. \(O(1)\).
isEmpty :: CharMap a -> Bool
isEmpty Empty = True
isEmpty _ = False

-- | Create a singleton map. \(O(1)\).
singleton :: Char -> a -> CharMap a
singleton k v = Node B Empty k v Empty

-- | Check if a map is a singleton, returning the key-value pair if it is.
-- \(O(1)\).
isSingleton :: CharMap a -> Maybe (Char, a)
isSingleton = _isSingleton

-- | Enforce the Red-Black invariants. \(O(1)\).
--
-- Eliminates red-red violations by pulling the red colour up.
balance :: Colour -> CharMap a -> Char -> a -> CharMap a -> CharMap a
balance B (Node R (Node R a xk xv b) yk yv c) zk zv d = _
balance B (Node R a xk xv (Node R b yk yv c)) zk zv d = _
balance B a xk xv (Node R (Node R b yk yv c) zk zv d) = _
balance B a xk xv (Node R b yk yv (Node R c zk zv d)) = _
balance col l k v r = Node col l k v r

-- | Insert with a combining function for collisions. \(O(\log{}(A))\).
--
-- The combining function is applied as @f new old@.
--
-- >>> let m1 = insert 'a' 1 empty
-- >>> let m2 = insertWith (+) 'a' 2 m1
-- >>> lookup 'a' m2
-- Just 3
insertWith :: (a -> a -> a) -> Char -> a -> CharMap a -> CharMap a
insertWith = _insertWith

-- | Insert a key-value pair into the map, overwriting values if the key already
-- exists. \(O(\log{}(A))\).
insert :: Char -> a -> CharMap a -> CharMap a
insert = _insert

-- | Look up the value associated with a key. \(O(\log{}(A))\).
lookup :: Char -> CharMap a -> Maybe a
lookup = _lookup

-- | /Strict/ left fold over key-value pairs. \(O(A)\).
foldlWithKey' :: (b -> Char -> a -> b) -> b -> CharMap a -> b
foldlWithKey' = _foldlWithKey'

-- | Build a map from a list of key-value pairs. \(O(N\log{}(A))\). Retains the
-- latest values on key collisions.
--
-- >>> toAscList (fromList [('b', 2), ('a', 1)])
-- [('a',1),('b',2)]
fromList :: [(Char, a)] -> CharMap a
fromList = _fromList -- Hint: Use foldl' and insert!

-- | Convert the map to an association list in ascending order of keys.
-- \(O(A)\). Avoids \(O(A^2)\) concatenations by building the list
-- right-to-left.
toAscList :: CharMap a -> [(Char, a)]
toAscList = _toAscList
