module PriorityQueue
  ( Heap,
    empty,
    isEmpty,
    singleton,
    isSingleton,
    insert,
    merge,
    findMin,
    deleteMin,
    popMin,
    fromList,
    toPrioList,
  )
where

import Data.Foldable (Foldable (foldl'))

-- | The Heap data structure.
--
-- The 'Int' field tracks the weight (total number of nodes) of the subtree.
--
-- Invariant: For any @Node w _ l r@, @weight l >= weight r@, ensuring the right
-- spine length is bounded by \(O(\log{}(N))\).
--
-- Follows Okasaki's Weight-Biased Leftist Heap (Ch. 3 of "Purely Functional
-- Data Structures").
data Heap a
  = Empty
  | Node !Int !a !(Heap a) !(Heap a)
  deriving (Show, Eq)

-- | The empty heap. \(O(1)\).
empty :: Heap a
empty = Empty

-- | Check if the heap is empty. \(O(1)\).
isEmpty :: Heap a -> Bool
isEmpty Empty = True
isEmpty _ = False

-- | Create a singleton heap. \(O(1)\).
singleton :: a -> Heap a
singleton x = Node 1 x Empty Empty

-- | Check if the heap is a singleton, returning the element if it is. \(O(1)\).
isSingleton :: Heap a -> Maybe a
isSingleton = _isSingleton

-- | Get the weight (or, node count) of a heap. \(O(1)\).
weight :: Heap a -> Int
weight Empty = 0
weight (Node w _ _ _) = w

-- | Smart constructor for 'Node's that enforces the leftist property by weight.
-- \(O(1)\).
buildNode :: a -> Heap a -> Heap a -> Heap a
buildNode = _buildNode

-- | Merge two heaps, retaining duplicates. \(O(\log{}(N))\).
-- Recursively merges along the right spines of both heaps.
--
-- >>> let h1 = fromList [3, 5]
-- >>> let h2 = fromList [2, 1]
-- >>> let h3 = merge h1 h2
-- >>> h3
-- >>> findMin h3
-- Node 4 1 (Node 2 3 (Node 1 5 Empty Empty) Empty) (Node 1 2 Empty Empty)
-- Just 1
merge :: (Ord a) => Heap a -> Heap a -> Heap a
merge h Empty = h
merge Empty h = h
merge h1@(Node _ x l1 r1) h2@(Node _ y l2 r2) = _merge

-- | Insert a single element into a heap. \(O(\log{}(N))\).
insert :: (Ord a) => a -> Heap a -> Heap a
insert = _insert

-- | Peek at the minimum element. \(O(1)\).
findMin :: Heap a -> Maybe a
findMin = _findMin

-- | Remove the minimum element from a heap. \(O(\log{}(N))\).
deleteMin :: (Ord a) => Heap a -> Maybe (Heap a)
deleteMin = _deleteMin

-- | Remove and return the minimum element. \(O(\log{}(N))\).
popMin :: (Ord a) => Heap a -> Maybe (a, Heap a)
popMin = _popMin

-- | Build a heap from a list of elements. \(O(N\log{}(N))\).
fromList :: (Ord a) => [a] -> Heap a
fromList = _fromList

-- | Dump a heap to a sorted list (ascending order). \(O(N\log{}(N))\).
toPrioList :: (Ord a) => Heap a -> [a]
toPrioList = _toPrioList
