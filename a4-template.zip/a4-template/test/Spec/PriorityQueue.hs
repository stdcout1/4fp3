module Spec.PriorityQueue (priorityQueueTests) where

import Data.List (sort)
import Data.Maybe (isNothing)
import Hedgehog
import Hedgehog.Gen qualified as Gen
import Hedgehog.Range qualified as Range
import PriorityQueue (toPrioList)
import PriorityQueue qualified as PQ
import Test.Tasty
import Test.Tasty.HUnit
import Test.Tasty.Hedgehog

priorityQueueTests :: TestTree
priorityQueueTests =
  testGroup
    "PriorityQueue"
    [ unitTests,
      propertyTests
    ]

--------------------------------------------------------------------------------
-- Unit Tests
--------------------------------------------------------------------------------

unitTests :: TestTree
unitTests =
  testGroup
    "unit tests"
    [ testCase "empty heap" $ do
        assertBool "isEmpty is True" (PQ.isEmpty (PQ.empty @Int))
        assertBool "findMin is Nothing" (isNothing $ PQ.findMin (PQ.empty @Int))
        assertBool "deleteMin is Nothing" (isNothing $ PQ.deleteMin (PQ.empty @Int))
      -- YOUR TESTS HERE!
    ]

--------------------------------------------------------------------------------
-- Property Tests
--------------------------------------------------------------------------------

genInts :: Gen [Int]
genInts = Gen.list (Range.linear 0 1000) (Gen.int (Range.constant (-10000) 10000))

propertyTests :: TestTree
propertyTests =
  testGroup
    "property tests"
    [ -- YOUR TESTS HERE!
    ]
