{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{- HLINT ignore "Use <$>" -}
{- HLINT ignore "Avoid lambda" -}
-- |
module A5.Compile
  (
  -- * Expressions
    Expr(..)
  , Var(..)
  -- * Computations
  , UnOp(..)
  , BinOp(..)
  , Step(..)
  , Prog(..)
  , FreshM(..)
  , freshName
  ) where

import A5.Language

--------------------------------------------------------------------------------
-- Expressions

-- | Variables.
data Var
  = User String
  -- ^ User-written variables.
  | Machine Int
  -- ^ Machine generated names.
  deriving (Show, Ord, Eq)

data Expr
  = Var Var
  | Int Int
  | Bool Bool
  | Array [Expr]
  deriving (Show, Ord, Eq)

data UnOp
  = Not
  | Length
  deriving (Show, Ord, Eq)

data BinOp
  = Add
  | Sub
  | Mul
  | And
  | Or
  | Leq
  | Lt
  | Get
  deriving (Show, Ord, Eq)

data TernOp = Set
  deriving (Show, Ord, Eq)

data Step
  = UnOp UnOp Expr
  | BinOp BinOp Expr Expr
  | TernOp TernOp Expr Expr Expr
  | ForUp Expr Expr Expr Prog
  | ForDown Expr Expr Expr Prog
  deriving (Show, Ord, Eq)

data Prog
  = Step Step
  | Let Step Prog
  | If Expr Prog Prog
  | Ret Expr
  | Crash String
  deriving (Show, Ord, Eq)

newtype FreshM a = FreshM { runFreshM :: Int -> a }
  deriving (Functor, Applicative, Monad)

-- | Generate a fresh name.
freshName :: (Expr -> FreshM a) -> FreshM a
freshName k = FreshM \i ->
  runFreshM (k (Var (Machine i))) $! i + 1

instance Lang Expr (FreshM Prog) where
  int = _
  add = _
  sub = _
  mul = _

  bool = _
  not = _
  and = _
  or = _
  xor = _
  leq = _
  lt = _

  array = _
  getArray = _
  setArray = _
  lenArray = _

  let_ prog body = _
  ret x = _

  forUp lo hi acc body = _

  forDown hi lo acc body = _

  if_ b prog1 prog2 = _

  crash msg = _

interpretExpr :: (Lang val cmp) => Expr -> (Var -> val) -> val
interpretExpr = _

interpretStep :: (Lang val cmp) => Step -> (Var -> val) -> cmp
interpretStep = _

interpretProg :: (Lang val cmp) => Prog -> (Var -> val) -> cmp
interpretProg = _
