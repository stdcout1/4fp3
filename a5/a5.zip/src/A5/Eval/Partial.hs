{-# LANGUAGE DeriveFunctor #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{- HLINT ignore "Avoid lambda" -}
-- | Partial evaluation.
module A5.Eval.Partial
  ( Type(..)
  , GluedVal(..)
  , GluedArray(..)
  , DynamicInt(..)
  , DynamicBool(..)
  , GluedProg(..)
  , staticInt
  , staticBool
  , staticArray
  , dynamic
  , residualProg
  , residualVal
  ) where
import Prelude hiding (not, and, or)

import A5.Data.Array.Pure (Array)
import A5.Data.Array.Pure qualified as Array

import Data.Semigroup

import A5.Language
import A5.Poly.Sparse (Poly)
import A5.Poly.Sparse qualified as Poly

import Control.Monad

--------------------------------------------------------------------------------
-- Types

data Type
  = TpInt
  | TpBool
  | TpArray
  | TpUnknown
  deriving (Show, Ord, Eq)

prettyType :: Type -> String
prettyType TpInt = "int"
prettyType TpBool = "bool"
prettyType TpArray = "array"
prettyType TpUnknown = "dynamic"

--------------------------------------------------------------------------------
-- Values

-- | Values.
data GluedVal var
  = GInt (GluedInt var)
  -- ^ Integers.
  | GBool (GluedBool var)
  -- ^ Boolean.
  | GArray (GluedArray var)
  -- ^ Arrays.
  | GUnknown var
  -- ^ Things of dynamic type.
  deriving (Show, Ord, Eq)

type GluedInt var = Poly Int (Sum Word) (DynamicInt var)

-- | Dynamic integers.
data DynamicInt var
  = IVar var
  -- ^ A variable.
  | ILength var
  -- ^ The length of a dynamic array.
  deriving (Show, Eq, Ord)

type GluedBool var = Poly Bool Any (DynamicBool var)

-- | Dynamic booleans.
data DynamicBool var
  = BVar var
  | BLeq (GluedInt var) (GluedInt var)
  | BLt (GluedInt var) (GluedInt var)
  deriving (Show, Ord, Eq)


data GluedArray var
  = StaticArray (Array (GluedVal var))
  -- ^ A fully static array.
  | DynamicArray var
  -- ^ A dynamic array.
  deriving (Show, Ord, Eq)

dynamic :: (Ord var) => var -> Type -> GluedVal var
dynamic var TpInt = GInt (Poly.id (IVar var))
dynamic var TpBool = GBool (Poly.id (BVar var))
dynamic var TpArray = GArray (DynamicArray var)
dynamic var TpUnknown = GUnknown var

staticInt :: Int -> GluedVal var
staticInt i = GInt (Poly.const i)

staticBool :: Bool -> GluedVal var
staticBool b = GBool (Poly.const b)

staticArray :: Array (GluedVal var) -> GluedVal var
staticArray = GArray . StaticArray

valType :: GluedVal var -> Type
valType (GInt _) = TpInt
valType (GBool _) = TpBool
valType (GArray _) = TpArray
valType (GUnknown _) = TpUnknown

--------------------------------------------------------------------------------
-- Computations

data GluedStep var
  = GGetDynamicArray (GluedArray var) (GluedInt var)
  | GSetDynamicArray (GluedArray var) (GluedInt var) (GluedVal var)
  | GForUp (GluedInt var) (GluedInt var) (GluedVal var) (var -> var -> GluedProg var (GluedVal var))
  | GForDown (GluedInt var) (GluedInt var) (GluedVal var) (var -> var -> GluedProg var (GluedVal var))

data GluedProg var a
  = GRet a
  | GCrash String
  | GLet (GluedStep var) (var -> GluedProg var a)
  | GIf (GluedBool var) (GluedProg var a) (GluedProg var a)
  deriving (Functor)


instance Applicative (GluedProg var) where
  pure = GRet
  (<*>) = ap

instance Monad (GluedProg var) where
  return = pure
  (GRet a) >>= f = f a
  GCrash msg >>= _ = GCrash msg
  GLet step prog >>= f = GLet step (prog >=> f)
  GIf b prog1 prog2 >>= f = GIf b (prog1 >>= f) (prog2 >>= f)

instance MonadFail (GluedProg var) where
  fail = GCrash

--------------------------------------------------------------------------------
-- Checks

unwrapBool :: (Ord var) => String -> GluedVal var -> GluedProg var (GluedBool var)
unwrapBool _loc (GBool b) = pure b
unwrapBool _loc (GUnknown var) = pure (Poly.id (BVar var))
unwrapBool loc v =
  fail $ unlines
  [ "type error."
  , "Expected a bool in the " <> loc
  , "but got something of type " <> prettyType (valType v)
  ]

unwrapInt :: (Ord var) => String -> GluedVal var -> GluedProg var (GluedInt var)
unwrapInt _loc (GInt n) = pure n
unwrapInt _loc (GUnknown var) = pure (Poly.id (IVar var))
unwrapInt loc v =
  fail $ unlines
  [ "type error."
  , "Expected a bool in the " <> loc
  , "but got something of type " <> prettyType (valType v)
  ]

unwrapArray :: String -> GluedVal var -> GluedProg var (GluedArray var)
unwrapArray _loc (GArray arr) = pure arr
unwrapArray loc v =
  fail $ unlines
  [ "Type error:"
  , "Expected an array in the " <> loc
  , "but got something of type " <> prettyType (valType v)
  ]

intBinOp :: (Ord var) => String -> (GluedInt var -> GluedInt var -> GluedInt var) -> GluedVal var -> GluedVal var -> GluedProg var (GluedVal var)
intBinOp name f x y = do
  vx <- unwrapInt ("first argument of " <> name) x
  vy <- unwrapInt ("second argument of " <> name) y
  pure (GInt (f vx vy))

intCmpOp :: (Ord var) => String -> (GluedInt var -> GluedInt var -> GluedBool var) -> GluedVal var -> GluedVal var -> GluedProg var (GluedVal var)
intCmpOp name f x y = do
  vx <- unwrapInt ("first argument of " <> name) x
  vy <- unwrapInt ("second argument of " <> name) y
  pure (GBool (f vx vy))

boolUnOp :: (Ord var) => String -> (GluedBool var -> GluedBool var) -> GluedVal var -> GluedProg var (GluedVal var)
boolUnOp name f x = do
  vx <- unwrapBool ("first argument of " <> name) x
  pure (GBool (f vx))

boolBinOp :: (Ord var) => String -> (GluedBool var -> GluedBool var -> GluedBool var) -> GluedVal var -> GluedVal var -> GluedProg var (GluedVal var)
boolBinOp name f x y = do
  vx <- unwrapBool ("first argument of " <> name) x
  vy <- unwrapBool ("second argument of " <> name) y
  pure (GBool (f vx vy))

--------------------------------------------------------------------------------
-- Interpretation

instance (Ord var) => Lang (GluedVal var) (GluedProg var (GluedVal var)) where
  int n = _
  add x y = _
  sub x y = _
  mul x y = _

  bool b = _
  xor x y = _
  and x y = _
  or x y = _
  not x = _
  leq x y = _
  lt x y = _


  array vs = _

  getArray arr i = _

  setArray arr i v = _
  lenArray arr = _

  let_ c body = _
  ret = _

  forUp lo hi acc body = _

  forDown hi lo acc body = _

  if_ b c1 c2 = _

  crash = _

--------------------------------------------------------------------------------
-- Residualizing
--
-- You do not need to touch this code.

residualProg :: (Lang val cmp) => GluedProg val (GluedVal val) -> cmp
residualProg (GRet val) = residualVal val ret
residualProg (GCrash msg) = crash msg
residualProg (GLet neu body) = let_ (residualStep neu) (residualProg . body)
residualProg (GIf b prog1 prog2) =
  residualBool b \vb ->
  if_ vb (residualProg prog1) (residualProg prog2)

residualStep :: (Lang val cmp) => GluedStep val -> cmp
residualStep (GGetDynamicArray arr i) =
  residualArray arr \rarr ->
  residualInt i \ri ->
  getArray rarr ri
residualStep (GSetDynamicArray arr i v) =
  residualArray arr \rarr ->
  residualInt i \ri ->
  residualVal v \rv ->
  setArray rarr ri rv
residualStep (GForUp lo hi acc body) =
  residualInt lo \rlo ->
  residualInt hi \rhi ->
  residualVal acc \racc ->
  forUp rlo rhi racc \varinit varacc -> residualProg (body varinit varacc)
residualStep (GForDown hi lo acc body) =
  residualInt hi \rhi ->
  residualInt lo \rlo ->
  residualVal acc \racc ->
  forDown rhi rlo racc \varinit varacc -> residualProg (body varinit varacc)

residualVal :: (Lang val cmp) => GluedVal val -> (val -> cmp) -> cmp
residualVal (GInt n) = residualInt n
residualVal (GBool b) = residualBool b
residualVal (GArray arr) = residualArray arr
residualVal (GUnknown v) = \k -> k v

residualInt :: (Lang val cmp) => Poly Int (Sum Word) (DynamicInt val) -> (val -> cmp) -> cmp
residualInt p k =
  case Poly.viewConst p of
    Just i -> k (int i)
    Nothing ->
      runArith $ Poly.eval p (Arith . ret . int) (\c n -> c Poly.^ getSum n) \case
        IVar x -> Arith (k x)
        ILength x -> Arith (let_ (lenArray x) k)

residualBool :: (Lang val cmp) => Poly Bool Any (DynamicBool val) -> (val -> cmp) -> cmp
residualBool p k =
  case Poly.viewConst p of
    Just b -> k (bool b)
    Nothing ->
      runLogic $ Poly.eval p (Logic . ret . bool) (\c b -> if getAny b then c else Logic (ret $ bool True)) \case
        BVar x -> Logic (k x)
        BLeq x y -> Logic $
          residualInt x \rx ->
          residualInt y \ry ->
          let_ (leq rx ry) k
        BLt x y -> Logic $
          residualInt x \rx ->
          residualInt y \ry ->
          let_ (lt rx ry) k

residualArray :: (Lang val cmp) => GluedArray val -> (val -> cmp) -> cmp
residualArray (DynamicArray val) k = k val
residualArray (StaticArray vs) k =
  foldl (\k' v rvs -> residualVal v \rv -> k' (rv:rvs)) (k . array) vs []
