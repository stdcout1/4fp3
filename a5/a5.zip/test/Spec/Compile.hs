-- |
module Spec.Compile
  ( compileSpec
  ) where

import Test.Tasty
import Test.Tasty.HUnit

compileSpec :: TestTree
compileSpec =
  testGroup "Compile"
  [ testCase "The A5.Compile module should be tested" $
      assertFailure "No test cases for A5.Compile implemented!"
  ]
