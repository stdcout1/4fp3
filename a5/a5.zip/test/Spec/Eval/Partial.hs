-- | Spec for @A5.Eval.Partial@.
module Spec.Eval.Partial
  ( evalPartialSpec
  ) where

import A5.Data.Array.Pure qualified as Array

import A5.Compile
import A5.Eval.Partial
import A5.Language

import Spec.Programs

import Test.Tasty
import Test.Tasty.HUnit

assertResidualizesTo :: GluedProg Expr (GluedVal Expr) -> FreshM Prog -> Assertion
assertResidualizesTo c expected = do
  runFreshM (residualProg c) 0 @?= runFreshM expected 0

evalPartialSpec :: TestTree
evalPartialSpec =
  testGroup "Eval.Pure"
  [ testCase "plus 2 5 == 7" $
      assertResidualizesTo (plus (staticInt 2) (staticInt 5)) $
        ret (int 7)
  , testCase "plus 2 x == x + 2" $
      let x = Var (User "x")
      in assertResidualizesTo (plus (staticInt 2) (dynamic x TpInt)) $
        x `add` int 2
  , testCase "time 2 5 == 10 " $
      assertResidualizesTo (times (staticInt 2) (staticInt 5)) $
        ret (int 10)
  , testCase "time 2 x == x * 2" $
      let x = Var (User "x")
      in assertResidualizesTo (times (staticInt 2) (dynamic (Var (User "x")) TpInt)) $
        x `mul` int 2
  , testCase "power x 4 == let y = x * x in y * y" $
      let x = Var (User "x")
      in assertResidualizesTo (power (dynamic (Var (User "x")) TpInt) (staticInt 4)) $
        let_ (x `mul` x) \xSquare ->
        xSquare `mul` xSquare
  , testCase "insertionSort [x, y] == if (y < x) then [y, x] else [x, y]" $
      let x = Var (User "x")
          y = Var (User "y")
      in assertResidualizesTo (insertionSort $ staticArray $ Array.fromList [dynamic x TpInt, dynamic y TpInt]) $
        let_ (lt y x) \cmp ->
        if_ cmp
          (ret $ array [y, x])
          (ret $ array [x, y])
  , testCase "insertionSort [2, x, 1]" $
      let x = Var (User "x")
          xs = [staticInt 2, dynamic x TpInt, staticInt 1]
      in assertResidualizesTo (insertionSort $ staticArray $ Array.fromList xs) $
        let_ (x `lt` int 2) \cmpx2 ->
        if_ cmpx2
          (let_ (int 1 `lt` x) \cmpx1 ->
           if_ cmpx1
             (ret $ array [int 1, x, int 2])
             (ret $ array [x, int 1, int 2]))
          -- A more clever implementation would be able to eliminate this
          -- branch: why can we eliminate it, and what strategies could we
          -- use to extend our partial evaluator to handle this?
          (let_ (int 1 `lt` x) \cmpx1 ->
           if_ cmpx1
             (ret $ array [int 1, int 2, x])
             (let_ (x `lt` int 2) \absurd ->
               if_ absurd
                 (ret $ array [x, int 2, int 1])
                 (ret $ array [int 2, x, int 1])))
  , testCase "alwaysCrash x == crash" $
    let x = dynamic (Var (User "x")) TpBool
    in assertResidualizesTo (alwaysCrash x) $
      crash $ unlines
      [ "type error."
      , "Expected a bool in the second argument of add"
      , "but got something of type bool"
      ]
  ]
