module A6.Para
  ( -- * Paramorphisms
    RAlgebra,
    para,

    -- * Lists
    deleteMin,
    findMin,
    wordCount,
  )
where

import A6.CataAna
import A6.Fix (Fix (..))

--------------------------------------------------------------------------------
-- PARAMORPHISMS
--------------------------------------------------------------------------------

type RAlgebra f a = f (Fix f, a) -> a

para :: (Functor f) => RAlgebra f a -> Fix f -> a
para alg = alg . fmap (\x -> (x, para alg x)) . out

--------------------------------------------------------------------------------
-- LIST OPERATIONS
--------------------------------------------------------------------------------

deleteMinAlg :: (Ord a) => RAlgebra (ListF a) (Maybe (a, List a))
deleteMinAlg NilF = _
deleteMinAlg (ConsF x (xs, Nothing)) = _
deleteMinAlg (ConsF x (xs, Just (m, tl))) = _

-- | Delete the /first occurrence/ of the minimum element in a list.
deleteMin :: (Ord a) => List a -> Maybe (a, List a)
deleteMin = para deleteMinAlg

findMinAlg :: (Ord a) => RAlgebra (ListF a) (Maybe (List a, a, List a))
findMinAlg = _

-- | Find the minimum element in a list, along with the elements to the left and
-- right of the /first occurrence/ of the minimum element.
findMin :: (Ord a) => Fix (ListF a) -> Maybe (List a, a, List a)
findMin = para findMinAlg

--------------------------------------------------------------------------------
-- WORD COUNTING
--------------------------------------------------------------------------------

wordCountAlg :: RAlgebra (ListF Char) Int
wordCountAlg = _

-- | Count the number of words in a string.
wordCount :: List Char -> Int
wordCount = para wordCountAlg

-- | A character is whitespace if it is a space, tab, or newline.
isSpace :: Char -> Bool
isSpace ' ' = True
isSpace '\t' = True
isSpace '\n' = True
isSpace _ = False
