module A6.RegExp
  ( RE (..),
    RESize (..),
    smallest,
    largest,
    genFunc,
    powerSeries,
  )
where

import A6.Poly (Poly (..))
import Numeric.Natural

--------------------------------------------------------------------------------
-- REGULAR EXPRESSIONS
--------------------------------------------------------------------------------

data RE
  = Eps
  | Ch Char
  | RE :+: RE
  | RE :->: RE
  | Star RE
  deriving (Eq, Show)

-- | The size of the smallest string in the language of a regular expression.
smallest :: RE -> Natural
smallest = _

data RESize = Finite Natural | Infinite
  deriving (Eq, Show)

instance Ord RESize where
  _ <= _ = _

-- | The size of the largest string in the language of a regular expression, or
-- 'Infinite' if there is no largest string.
largest :: RE -> RESize
largest = _

data RatExpr = RatExpr Poly Poly
  deriving (Eq, Show)

-- | Calculates the ordinary generating function (OGF) for a regular expression,
-- represented as a rational expression (a ratio of two polynomials).
genFunc :: RE -> RatExpr
genFunc = _

-- | The first $n$ terms of the power series expansion of the generating
-- function for a given regular expression.
powerSeries :: Int -> RE -> [Rational]
powerSeries = _
