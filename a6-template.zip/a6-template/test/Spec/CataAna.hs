module Spec.CataAna (cataAnaSpec) where

import Test.Tasty (TestTree, testGroup)

cataAnaSpec :: TestTree
cataAnaSpec =
  testGroup
    "CataAna"
    [ -- FIXME: add tests!
    ]
