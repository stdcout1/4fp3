module Spec.Para (paraSpec) where

import Test.Tasty (TestTree, testGroup)

paraSpec :: TestTree
paraSpec =
  testGroup
    "Para"
    [ -- FIXME: add tests!
    ]
