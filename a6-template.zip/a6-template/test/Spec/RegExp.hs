module Spec.RegExp (regExpSpec) where

import Test.Tasty (TestTree, testGroup)

regExpSpec :: TestTree
regExpSpec =
  testGroup
    "RegExp"
    [ -- FIXME: add tests!
    ]
